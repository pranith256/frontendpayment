import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Redirect,
  Switch
} from 'react-router-dom';
import About from './pages/About/About';
import Contact from './pages/Contact/Contact';
import Home from './pages/Home/Home';
import Login from './pages/Login/login';
import Testimonial from './pages/Banklogin/Banklogin';
import Navbar from './Components/Navbar/Navbar';
import Banklogin from './pages/Banklogin/Banklogin';
import Menu from './pages/Menu';
import MenuContainer from './pages/Menu';
import Profile from './pages/Profile/Profile';

import Balance from './pages/Balance/balance';
import Transaction from './pages/Transaction/transaction';
import Transfer from './pages/Transaction/transaction';
import Success from './pages/Success';
import History from './pages/History/history';
import Picture from './pages/Picture/picture';

const App = () => {
  return (

     
     <Router>
       
     <Switch>
    <Route path="/profile" exact  component={Profile}></Route>
    <Route path="/dashboard" exact  component={MenuContainer}/>
    <Route path="/profile" exact  component={Profile}/>
    <Route path="/history" exact  component={History}/>
    <Route path="/balance" exact  component={Balance}/>
    <Route path="/transfer" exact  component={Transfer}/>
    <Route path="/" exact component={Picture}/>
         <Route path="/Home" exact>
       <Home/>
        </Route>
         <Route path="/customerlogin" exact>
           <Login/>
         </Route>
         <Route path="/banklogin" exact>
           <Banklogin/>
         </Route>
         <Route path="/About" exact>
           <About/>
      </Route>
      <Route path="/success" exact component={Success}/>
         <Route path="/" exact>
           <Home/>
         </Route>
       </Switch>
   </Router>

  );
}

export default App;
