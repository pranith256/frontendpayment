const Success = ()=>{
    return(
        
<div class="container">
	<div class="row text-center">
        <div class="col-sm-6 col-sm-offset-3">
        <h2 >Transaction Successful</h2>
        
        </div>
        
	</div>
</div>
    )
}

export default Success;