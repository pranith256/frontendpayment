const banks = [
    
    { bic:"ABBLINBBXXX" ,bank:"AB BANK LIMITED"},
    { bic:"ABNAINBBAHM",bank:"ABN AMRO BANK N.V." },
    {bic:"ACBLINBBXXX",bank:"ABHYUDAYA CO-OPERATIVE BANK LTD."}
  ]

 

  export const getBanks=()=>{
    return banks;
}