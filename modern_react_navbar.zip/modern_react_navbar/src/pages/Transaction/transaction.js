import { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
// import './Transfer.css';
import { getBanks } from "./bankconstants";
import axios from "axios";
const Transfer = () => {
    const messages = {'CHBQ':"beneficiary customer must be paid by cheque only."}
    const [bank,setBank] = useState("");
    const [msgcode,setMsg] = useState("");
    const [bic,setBIC] = useState("");
    const [transfertype,setTransfertype] = useState("");
    const [amount,setAmount]=useState("");
    const [rname,setRname]=useState("");
    const [rno,setRno]=useState("");
    const [errormsg,setError] = useState("");


    // const [transferdata,setTransferdata] = useState({
    //     "sendCustomerId":localStorage.getItem("customerid"),
    //     "senderBIC":"DBS bank","currencyCode":"INR","receiverBIC":bic,
    //     "receiverAccountNumber":rno,"receiverAccHolderName":rname,"transferTypeId":transfertype,"transferAmount":amount,"employeeId":21,"userid":34
    //     })

    const [transferdata,setTransferdata] = useState({
        "sendCustomerId":localStorage.getItem("customerid"),
        "senderBIC":"ACBLINBBXXX","currencyCode":"INR","receiverBIC":"",
        "receiverAccountNumber":"","messagecode":"",receiverAccHolderName:"","transferTypeId":"B","transferAmount":"","employeeId":21,"userid":34
        })

    const handleInputChange = (e) => {
        if (e.target.name === "BIC") {
            e.target.code = getBanks()[e.target.selectedIndex].value;
        setBank(getBanks()[e.target.selectedIndex].bank)   
        setBIC(getBanks()[e.target.selectedIndex].bic)
        
    console.log(bank)    
 }
 if(e.target.name==="amount"){
     setAmount(e.target.value);
 }
 if(e.target.name==="msgcode"){
    setMsg(e.target.value);
}
//  if(e.target.name==="transfer"){
//     setTransfertype(e.target.value);
//  }
 if(e.target.name==="rname"){
     setRname(e.target.value)
 }
 if(e.target.name==="rno"){
    setRno(e.target.value)
}
setTransferdata({
    ...transferdata,"receiverBIC":bic,
          
        "receiverAccountNumber":rno,
        "receiverAccHolderName":rname,"messagecode":msgcode,"transferAmount":parseFloat(amount)
})
}
 
const history = useHistory()
    const bankOptions = getBanks().map((item, index) => {
        return <option value={item.bic} key={item.value}>{item.bic}</option>
    });
    const onSubmitTransfer =()=>{
        console.log(transferdata)
        
        axios.post("http://localhost:8080/transfer/initTransfer",transferdata)
        .then(
            response => {
                const data = response.data
                console.log(response.data)
                console.log(response.message=="Insufficient Balance")
                if(response.status===200){
                    history.push('/success');
                }
               
            }
        )
    }
    return (
        <div  className="Transfer">
          
                <div class="form-group">
                    <label for="exampleFormControlInput1">Sender Account Name</label>
                    <input type="text" class="form-control" value={localStorage.getItem('sendername')} id="exampleFormControlInput1" disabled/>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Balance Available</label>
                    <input type="text" class="form-control" value={"Rs."+localStorage.getItem('cb')+".000"} id="exampleFormControlInput1" disabled  />
                </div>
                <div className="form-group">
                    <label>BIC:</label>
                    <select className="form-control" name="BIC"
                        value={bic}
                        onChange={handleInputChange}>
                        {bankOptions}
                    </select>
                </div>
                <div className="form-group">
                    <label>Institution Name:</label>
                    <input className="form-control" name="institutionName"
                        value={bank}/>
                </div>
                
                <div class="form-group">
                    <label for="exampleFormControlInput1">Receiver Account Name</label>
                    <input type="text" class="form-control" value={rname} name="rname" onChange={handleInputChange} id="exampleFormControlInput1" placeholder="name@example.com"/>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Receiver Account Number</label>
                    <input type="text" class="form-control" onChange={handleInputChange} value={rno} name="rno" id="exampleFormControlInput1"  />
                </div>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Currency</label>
                    <select class="form-control" id="exampleFormControlSelect1">
                        <option>INR</option>
                        <option>$</option>
                        <option>Euro</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">TransferType</label>
                    <select class="form-control" name="transfer" value={transfertype} onChange={handleInputChange} id="exampleFormControlSelect1">
                        <option>B</option>
                        <option>C</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">MessageCode</label>
                    <select class="form-control" name="msgcode" value={msgcode} onChange={handleInputChange} id="exampleFormControlSelect1">
                        <option>CHQB</option>
                        <option>CORT</option>
                        <option>HOLD</option>
                        <option>INTC</option>
                        <option>THOB</option>
                        <option>THOI</option>
                        <option>THON</option>
                        <option>REPA</option>
                        <option>SDVA</option>
                    </select>
                </div>
                
                    <div className="form-group">
                        <label>Amount</label>
                        <input
                            className="form-control"
                            type="text"
                            name="amount"
                            placeholder="Enter amount"
                            value={amount}
                            onChange={handleInputChange}
                        />
                    </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">TranferFee</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="0.25%" value="20"
                        placeholder="0" value={parseFloat(amount)*0.0025}
                        disabled
                         />
                </div>
                <h1 id="headerror" >{errormsg}</h1>
                <button type="submit" onClick={onSubmitTransfer} class="button-row">Submit</button>

        </div>
    )
}
export default Transfer;