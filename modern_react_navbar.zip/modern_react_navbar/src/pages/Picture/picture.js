import Navbar from "../../Components/Navbar/Navbar";
const Picture=()=>{
    return(
        <div>
            <Navbar/>
            <img src="./images/img5.jpg" ></img>
        </div>
    )

}
export default Picture;