const Balance = ()=>{
    return (
        <div > 
            <h1>Balance</h1>
        </div>
    )
}

export default Balance;