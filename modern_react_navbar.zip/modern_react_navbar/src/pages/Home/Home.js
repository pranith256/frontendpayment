import AliceCarousel from 'react-alice-carousel';
import "react-alice-carousel/lib/alice-carousel.css";
import { Link } from 'react-router-dom';
// import image1 from './img/1.jpg'
// import image2 from './img/2.jpg'
// import image3 from './img/3.jpg'
// import image4 from './img/4.jpg'
import "./Home.css";
import Navbar from "../../Components/Navbar/Navbar";
function Home(){

  return(
  <div className="App" >
    <Navbar />
     <AliceCarousel autoPlay autoPlayInterval="3000">
      <img src="./img/1.jpg" className="sliderimg" alt=""/>
      <img src="./img/2.jpg" className="sliderimg" alt=""/>
      <img src="./img/3.jpg" className="sliderimg" alt=""/>
      <img src="./img/4.jpg" className="sliderimg" alt=""/>
      {/* <img src={image2} className="sliderimg" alt=""/>
      <img src={image3} className="sliderimg" alt=""/>
      <img src={image4} className="sliderimg" alt=""/> */}
    </AliceCarousel>
     <Link to='/banklogin'><button class="button button1" id="button" >Login</button></Link>
         </div>
  )
}
export default Home;