import axios from 'axios';
import React from 'react';
import { useEffect, useState } from "react";
import './index.css';
const History =()=>{
    const [info,setinfo]=useState([]);
    axios.get("http://localhost:8080/transfer/"+localStorage.getItem("customerid")).then(
        rs=>{
             setinfo(rs.data);
            console.log(info)
        }
    )
    const items=info.map((item, index)=>{
        return <tr>
        <th scope="row">1</th>
        <td>{item.transactionid}</td>
        <td>{item.transferdate}</td>
        <td>{item.receiveraccountholdernumber}</td>
        <td>{item.receiveraccountholdername}</td>
        <td>{item.currencyamount}</td>
      </tr>
      })
  return (
    <div class="container-fluid" id="form" >
     <table  class="table table-dark">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Sc.no</th>
      <th scope="col">Transaction ID</th>
      <th scope="col">Transfer date</th>
      <th scope="col">ReceiverAccNumber</th>
      <th scope="col">ReceiverName</th>
      <th scope="col">Amount</th>
    </tr>
  </thead>
  <tbody>
      {items}
    {/* <tr>
      <th scope="row">1</th>
      <td>12345</td>
      <td>2021-04-30</td>
      <td>67898765456</td>
      <td>Sarayu</td>
      <td>30000</td>
    </tr> */}

  </tbody>
</table>



    </div>
  );
  }


export default History;




