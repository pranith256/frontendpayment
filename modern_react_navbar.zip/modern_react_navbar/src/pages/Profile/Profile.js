
import axios from 'axios';
import { useState } from 'react';
import './prof.css'
const Profile = ()=>{
    const cid = localStorage.getItem("customerid")
    const [username,setUsername] = useState("");
    const [btype,setBtype] =useState("");
    const [address,setAddress] = useState("");
    const [city,setCity] = useState("");
    const [balance , setBalance ] = useState(0);
    axios.get("http://localhost:8080/customer/"+cid).then(
        response=>{
            console.log(response.data)
            const userinfo = response.data
            localStorage.setItem("sendername",userinfo.accountholdername);
            setUsername(userinfo.accountholdername)
            setBtype(userinfo.customertype)
            setAddress(userinfo.customeraddress)
            setCity(userinfo.customercity)
            setBalance(userinfo.clearbalance)
            localStorage.setItem("cb",userinfo.clearbalance);
        }
    )
    return (
        <div class="page-content page-container" id="page-content">
    <div class="padding">
        <div class="row container d-flex justify-content-center">
            <div class="col-xl-6 col-md-12">
                <div class="card user-card-full">
                    <div class="row m-l-0 m-r-0">
                        <div class="col-sm-4 bg-c-lite-green user-profile">
                            <div class="card-block text-center text-white">
                                <div class="m-b-25"> <img src="https://img.icons8.com/bubbles/100/000000/user.png" class="img-radius" alt="User-Profile-Image"/> </div>
                                <h6 class="f-w-600">{username}</h6>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card-block">
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">CustomerID</p>
                                        <h6 class="text-muted f-w-400">{localStorage.getItem("customerid")}</h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Balance </p>
                                        <h6 class="text-muted f-w-400">INR-{balance}.00</h6>
                                    </div>
                                </div>
                                <h6 class="m-b-20 m-t-40 p-b-5 b-b-default f-w-600">Address</h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Locality</p>
                                        <h6 class="text-muted f-w-400">{address}</h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">City</p>
                                        <h6 class="text-muted f-w-400">{city}</h6>
                                    </div>
                                </div>
                                <ul class="social-link list-unstyled m-t-40 m-b-10">
                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="facebook" data-abc="true"><i class="mdi mdi-facebook feather icon-facebook facebook" aria-hidden="true"></i></a></li>
                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="twitter" data-abc="true"><i class="mdi mdi-twitter feather icon-twitter twitter" aria-hidden="true"></i></a></li>
                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="instagram" data-abc="true"><i class="mdi mdi-instagram feather icon-instagram instagram" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    )
}

export default Profile;