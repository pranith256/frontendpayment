import './about.css';
import Navbar from "../../Components/Navbar/Navbar";
const About = () => {
    return (
        <div>
          <Navbar/>
          <div id="data">
            <h1>Welcome to DBS Bank</h1>
            <p>We provide you easy banking in one go</p>
            <p>We provide you safety and security</p>
            <p>Enjoy banking with us</p>
           </div>
           <div class="container">
            <div class="row">
                <div >
                    <div class="card col-lg-3">
                        <img src="./images/img2.jpg" width="100" height="100" alt=""  id="img" />
                        <h3>Sanchita</h3>
                        <p class="title">Developer</p>
                        <p>DBS</p>
                        <p><button>Contact</button></p>
                    </div>
                    <div class="card col-lg-3">
                        <img src="./images/img1.jpg" width="100" height="100" alt=""  id="img" />
                        <h3>Harika</h3>
                        <p class="title">Developer</p>
                        <p>DBS</p>
                        <p><button>Contact</button></p>
                    </div>
                    <div class="card col-lg-3">
                        <img src="./images/img2.jpg" width="100" height="100" alt=""  id="img" />
                        <h3>Sarayu</h3>
                        <p class="title">Developer</p>
                        <p>DBS</p>
                        <p><button>Contact</button></p>
                    </div>
                </div>
            </div>
            

 

            <div class="row">
                <div class="col-lg-12">
                <div class="card col-lg-3">
                        <img src="./images/img3.jpg" width="100" height="100" alt=""  id="img" />
                        <h3>Pranith</h3>
                        <p class="title">Developer</p>
                        <p>DBS</p>

 

                        <p><button>Contact</button></p>
                    </div>

 

                    <div class="card col-lg-3">
                        <img src="./images/img3.jpg" width="100" height="100" alt=""  id="img" />
                        <h3>Sathwik</h3>
                        <p class="title">Developer</p>
                        <p>DBS</p>

 

                        <p><button>Contact</button></p>
                    </div>

 

                    <div class="card col-lg-3">
                        <img src="./images/img3.jpg" width="100" height="100" alt=""  id="img" />
                        <h3>Varshith</h3>
                        <p class="title">Developer</p>
                        <p>DBS</p>



                        <p><button>Contact</button></p>
                    </div>
                </div>
            </div>
            </div>
            
        </div>

    )
}
export default About;