import axios from "axios";
import React, { useState } from "react";
import { useHistory } from "react-router";
import './login.css'
import Navbar from "../../Components/Navbar/Navbar";
const Banklogin = () => {
  const [data,setData] = useState({un:"",pass:""});
  const history =useHistory();
  const [error,setError] = useState("");
  const handleChange= (e)=>{
    setData({
      ...data,[e.target.name]:e.target.value
    })
  }
  // const options = {
  //   method: 'POST',
  //   headers: {
  //     'Accept': 'application/json',
  //     'Content-Type': 'application/json;charset=UTF-8'
  //   },
  //   body: JSON.stringify(data)
  // };
  
  
  // }
  // window.fetch("http://localhost:8080/customer/71319440983198",options)
  // .then(response=>response.json()).then(result=>{
  // console.log(result);
  // })
 
  const handleClick=() =>{
    axios.post("http://localhost:8080/login",data).then(
      response =>{
        if(response.status==400 || response.status==404)
        {
          setError("Wrong Credentials")
        }
        else{
          console.log(response.data)
          const userinfo = response.data
          localStorage.setItem("customerid",userinfo.customerid)
          
          history.push("/dashboard")
        }
      }
    ).catch(
      er=>{
        console.log(er)
        setError("Wrong Credentials")
      }
    )
    }

    
        

  return (
    <div>
      <Navbar />
    <div class="login-wrapper">
    <form action="" class="form">
      <h2>Bank Login</h2>
      <p  id="errorid">{error}</p>
      <div class="input-group">
        <input type="text" value={data.id} name="un" onChange={handleChange} id="id" required/>
        <label for="loginUser">User Name</label>
      </div>
      <div class="input-group">
        <input type="password" value={data.pass} onChange={handleChange}  name="pass" id="pass" required/>
        <label for="loginPassword" >Password</label>
      </div>
      <input type="button" value="Login" class="submit-btn" onClick={handleClick}/>
      <a href="#forgot-pw" class="forgot-pw">Forgot Password?</a>
    </form>

    <div id="forgot-pw">
      <form action="" class="form">
        <a href="#" class="close">&times;</a>
        <h2>Reset Password</h2>
        <div class="input-group">
          <input type="email" name="email" id="email" required/>
          <label for="email">Email</label>
        </div>
        <input type="submit" value="Submit" class="submit-btn"/>
      </form>
    </div>
  </div>
  </div>
  );
};
export default Banklogin;